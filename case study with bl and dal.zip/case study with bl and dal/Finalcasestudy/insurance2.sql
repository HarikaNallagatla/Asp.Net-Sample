create database Insurance

create table Customers
(
	Cust_id int not null identity primary key,
	FullName varchar(50) not null,
	UserName varchar(50) not null,
	Password varchar(50) not null,
	ConfirmPassword varchar(50) not null,
	Email varchar(50) not null,
	Address varchar(70) not null,
	Gender varchar(10) not null
)

create table tblInsuranceAgents
(
	Agent_Id int not null  primary key,
	FullName varchar(50) not null,
	UserName varchar(50) not null,
	Password varchar(50) not null,
	ConfirmPassword varchar(50) not null,
	Email varchar(50) not null,
	Address varchar(70) not null,
	Gender varchar(10) not null,
	Manager_Id int not null refernces Manager(Manager_Id)
	
)

drop table Insurers

select * from Customers

select * from Insurers
delete tblInsuranceAgents


Create table Insurers
(
Ins_ID int not null primary key,
Password varchar(10) not null,
Name_of_Insurer  varchar(20) not null,
Name_of_Nominee varchar(20) not null,
DOB date not null,
Age int not null,
Mode_Of_Payement varchar(15) not null,
Policy_Name varchar(30) not null,
Address varchar(40) not null,
Name_Of_Guardian varchar (30),
InsuredAmount BIGINT not null,
Agent_Id int not null references tblInsuranceAgents(Agent_Id)
)

Alter table Insurers
Add  Agent_Id int 

create table Policies
(
Policy_Id int not null primary key,
Policy_Name varchar(20) not null
)


create table JeevanRakshak
(
Plan_no int not null primary key,
Policy_Id int references Policies(Policy_Id),
Policy_Tenure_inYears int not null,
Mode_Of_Payment varchar(15) not null,
Age int not null,
Payable_Premium_rate float not  null
)

create table jeevan_Anand
(
Plan_no int not null primary key,
Policy_Id int references Policies(Policy_Id),
Policy_Tenure_in_years int not null,
Mode_Of_Payment varchar(15) not null,
Age int not null,
Payable_Premium_rate float not  null
)

create table Jeevan_Lakshya
(
Plan_no int not null primary key,
Policy_Id int references Policies(Policy_Id),
Policy_Tenure_in_years int not null,
Mode_Of_Payment varchar(15) not null,
Age int not null,
Payable_Premium_rate float not  null
)


create table Manager
(
	Manager_Id int not null primary key,
	Manager_Name varchar(30),
	Manager_Password varchar(10)
)

drop table jeevan_Anand


Insert into Policies values(801,'Life Insurance')
Insert into Policies values(802, 'JeevanRakshak')
Insert into Policies values(803,'JeevanAnand')
Insert into Policies values(804,'JeevanLakshya')
Insert into JeevanRakshak values(1,802,10,'Monthly',18,2.87)
Insert into JeevanRakshak values(2,802,10,'Monthly',35,2.87)
Insert into JeevanRakshak values(3,802,10,'Monthly',50,2.87)
Insert into JeevanRakshak values(4,802,10,'Quarterly',18,2.50)
Insert into JeevanRakshak values(5,802,10,'Quarterly',35,2.50)
Insert into JeevanRakshak values(6,802,10,'Quarterly',50,2.50)
Insert into JeevanRakshak values(7,802,10,'Halfyearly',18,2.20)
Insert into JeevanRakshak values(8,802,10,'Halfyearly',35,2.20)
Insert into JeevanRakshak values(9,802,10,'Halfyearly',50,2.20)
Insert into JeevanRakshak values(10,802,10,'yearly',18,1.87)
Insert into JeevanRakshak values(11,802,10,'Yearly',35,1.87)
Insert into JeevanRakshak values(12,802,10,'Yearly',50,1.87)

Insert into JeevanRakshak values(13,802,15,'Monthly',18,2.97)
Insert into JeevanRakshak values(14,802,15,'Monthly',35,2.97)
Insert into JeevanRakshak values(15,802,15,'Monthly',50,2.97)
Insert into JeevanRakshak values(16,802,15,'Quarterly',18,2.70)
Insert into JeevanRakshak values(17,802,15,'Quarterly',35,2.70)
Insert into JeevanRakshak values(18,802,15,'Quarterly',50,2.70)
Insert into JeevanRakshak values(19,802,15,'Halfyearly',18,2.40)
Insert into JeevanRakshak values(20,802,15,'Halfyearly',35,2.40)
Insert into JeevanRakshak values(21,802,15,'Halfyearly',50,2.40)
Insert into JeevanRakshak values(22,802,15,'Yearly',18,2.20)
Insert into JeevanRakshak values(23,802,15,'Yearly',35,2.20)
Insert into JeevanRakshak values(24,802,15,'Yearly',50,2.20)

Insert into jeevan_Anand values(1,803,15,'Monthly',18,3.87)
Insert into jeevan_Anand values(2,803,15,'Monthly',35,3.87)
Insert into jeevan_Anand values(3,803,15,'Monthly',50,3.87)
Insert into jeevan_Anand values(4,803,15,'Quarterly',18,3.50)
Insert into jeevan_Anand values(5,803,15,'Quarterly',35,3.50)
Insert into jeevan_Anand values(6,803,15,'Quarterly',50,3.50)
Insert into jeevan_Anand values(7,803,15,'Halfyearly',18,3.10)
Insert into jeevan_Anand values(8,803,15,'Halfyearly',35,3.10)
Insert into jeevan_Anand values(9,803,15,'Halfyearly',50,3.10)
Insert into jeevan_Anand values(10,803,15,'Yearly',18,2.87)
Insert into jeevan_Anand values(11,803,15,'Yearly',35,2.87)
Insert into jeevan_Anand values(12,803,15,'Yearly',50,2.87) 

Insert into jeevan_Anand values(13,803,25,'Monthly',18,3.87)
Insert into jeevan_Anand values(14,803,25,'Monthly',35,3.87)
Insert into jeevan_Anand values(15,803,25,'Monthly',50,3.87)
Insert into jeevan_Anand values(16,803,25,'Quarterly',18,3.50)
Insert into jeevan_Anand values(17,803,25,'Quarterly',35,3.50)
Insert into jeevan_Anand values(18,803,25,'Quarterly',50,3.50)
Insert into jeevan_Anand values(19,803,25,'Halfyearly',18,3.10)
Insert into jeevan_Anand values(20,803,25,'Halfyearly',35,3.10)
Insert into jeevan_Anand values(21,803,25,'Halfyearly',50,3.10)
Insert into jeevan_Anand values(22,803,25,'Yearly',18,2.87)
Insert into jeevan_Anand values(23,803,25,'Yearly',35,2.87)
Insert into jeevan_Anand values(24,803,25,'Yearly',50,2.87)

Insert into  Jeevan_Lakshya values(1,804,13,'Monthly',18,4.97)
Insert into  Jeevan_Lakshya values(2,804,13,'Monthly',35,4.97)
Insert into  Jeevan_Lakshya values(3,804,13,'Monthly',50,4.97)
Insert into  Jeevan_Lakshya values(4,804,13,'Quarterly',18,4.70)
Insert into  Jeevan_Lakshya values(5,804,13,'Quarterly',35,4.70)
Insert into  Jeevan_Lakshya values(6,804,13,'Quarterly',50,4.70)
Insert into  Jeevan_Lakshya values(7,804,13,'Halfyearly',18,4.40)
Insert into  Jeevan_Lakshya values(8,804,13,'Halfyearly',35,4.40)
Insert into  Jeevan_Lakshya values(9,804,13,'Halfyearly',50,4.40)
Insert into  Jeevan_Lakshya values(10,804,13,'Yearly',18,4.20)
Insert into  Jeevan_Lakshya values(11,804,13,'Yearly',35,4.20)
Insert into  Jeevan_Lakshya values(12,804,13,'Yearly',50,4.20)

Insert into  Jeevan_Lakshya values(13,804,25,'Monthly',18,5.97)
Insert into  Jeevan_Lakshya values(14,804,25,'Monthly',35,5.97)
Insert into  Jeevan_Lakshya values(15,804,25,'Monthly',50,5.97)
Insert into  Jeevan_Lakshya values(16,804,25,'Quarterly',18,5.70)
Insert into  Jeevan_Lakshya values(17,804,25,'Quarterly',35,5.70)
Insert into  Jeevan_Lakshya values(18,804,25,'Quarterly',50,5.70)
Insert into  Jeevan_Lakshya values(19,804,25,'Halfyearly',18,5.40)
Insert into  Jeevan_Lakshya values(20,804,25,'Halfyearly',35,5.40)
Insert into  Jeevan_Lakshya values(21,804,25,'Halfyearly',50,5.40)
Insert into  Jeevan_Lakshya values(22,804,25,'Yearly',18,5.20)
Insert into  Jeevan_Lakshya values(23,804,25,'Yearly',35,5.20)
Insert into  Jeevan_Lakshya values(24,804,25,'Yearly',50,5.20)

select * from jeevan_Anand
