﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Finalcasestudy
{
    public partial class WebForm13 : System.Web.UI.Page
    {
        static string connection = ConfigurationManager.ConnectionStrings["InsuranceConn"].ConnectionString;//@"Server=INCHCMPC011397;Database=Insurance;Trusted_Connection=true";

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                switch (DropDownList1.Text)
                {

                    case "Insurance Agent":

                        string command = "Select * from tblInsuranceAgents where Agent_Id = '" + tbxoldpassword.Text.Trim() + "'";
                        using (SqlCommand cmd = new SqlCommand(command, con))
                        {

                            SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                            if (reader.HasRows)
                            {
                                cmd.Cancel();

                                while (reader.Read())
                                {
                                    if (reader["Password"].ToString() == tbxoldpassword.Text)
                                    {
                                        command = "Update tblInsuranceAgents set  Password = '" + txtChangePassword.Text.Trim() + "'";
                                        cmd.ExecuteNonQuery();
                                        MessageBox.Show("Your password had been reset successfully");
                                        Response.Redirect("~/OthersLoginPage.aspx");
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show("Invalid UserName or Password");
                                Response.Redirect("~/OthersLoginPage.aspx");
                            }


                        }
                        break;

                    case "Manager":
                        command = "Select * from Manager where Manager_Id = '" + tbxoldpassword.Text.Trim() + "'";
                        using (SqlCommand cmd = new SqlCommand(command, con))
                        {

                            SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                            if (reader.HasRows)
                            {
                                cmd.Cancel();

                                while (reader.Read())
                                {
                                    if (reader["Password"].ToString() == tbxoldpassword.Text)
                                    {
                                        command = "Update tblInsuranceAgents set  Password = '" + txtChangePassword.Text.Trim() + "'";
                                        cmd.ExecuteNonQuery();
                                        MessageBox.Show("Your password had been reset successfully");
                                        Response.Redirect("~/OthersLoginPage.aspx");
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show("Invalid UserName or Password");
                                Response.Redirect("~/OthersLoginPage.aspx");
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            tbxoldpassword.Text = " ";
            txtChangePassword.Text = " ";
            Response.Redirect("~/FirstPagee.aspx", false);
        }
    }
}








