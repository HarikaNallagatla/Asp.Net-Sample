﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceCasetudy_bls
{
    public class AgentRegistration
    {
        public void insRegistration(string)
        {


        } 
    }
}
