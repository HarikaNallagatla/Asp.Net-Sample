﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceCasestudy_DALs
{
    public class Class1
    {
        public void insRegistration()
        {
            using (SqlConnection con = new SqlConnection(GetConnectionString()))
            {
                con.Open();
                string command = "Select UserName from tblInsuranceAgents where UserName= '" + txtusername.Text.Trim() + "' ";
                SqlCommand cmd;
                cmd = new SqlCommand(command, con);
                SqlDataReader dr;
                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                if (dr.HasRows)
                {
                    Response.Write("<script>alert('Username you have entered already exists.Please enter another username!')</script>");
                    cmd.Cancel();
                }

                else
                {
                    command = "Insert into tblInsuranceAgents values(@Agent_Id,@FullName,@UserName,@Password,@ConfirmPassword,@Email,@Address,@Gender)";
                    SqlCommand insertagents = new SqlCommand(command, con);
                    insertagents.Parameters.AddWithValue("@Agent_Id", tbxAgentId.Text);
                    insertagents.Parameters.AddWithValue("@FullName", txtname.Text);
                    insertagents.Parameters.AddWithValue("@UserName", txtusername.Text);
                    insertagents.Parameters.AddWithValue("@Password", txtpassword.Text);
                    insertagents.Parameters.AddWithValue("@ConfirmPassword", txtconfirmpassword.Text);
                    insertagents.Parameters.AddWithValue("@Email", txtmail.Text);
                    insertagents.Parameters.AddWithValue("@Address", txtAddress.Text);
                    if (rdMale.Checked == true)
                    {
                        insertagents.Parameters.AddWithValue("@Gender", rdMale.Text);
                    }
                    else if (rdfemale.Checked == true)
                    {
                        insertagents.Parameters.AddWithValue("@Gender", rdfemale.Text);
                    }
                    insertagents.ExecuteNonQuery();
                    MessageBox.Show("You account has been created successfully");
                    Response.Redirect("~/FirstPagee.aspx");

                }
            }



        }

        public  static string  GetConnectionString()
        {
            string connection = @"Data Source=INCHCMPC011397;Initial Catalog=Insurance;Integrated Security=True;MultipleActiveResultSets=true"
        return connection;
        }
    }
}
