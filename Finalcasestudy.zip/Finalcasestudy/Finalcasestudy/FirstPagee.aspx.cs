﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows.Forms;

/*Pease add the windows.Forms dll to the project*/

namespace Finalcasestudy
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        static string connection = ConfigurationManager.ConnectionStrings["InsuranceConn"].ConnectionString;//@"Server=INCHCMPC011397;Database=Insurance;Trusted_Connection=true";
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            //if (lblUSERTYPE.Text == "Customer")
            //{
            //    using (SqlConnection con = new SqlConnection(connection))
            //    {
            //        con.Open();
            //        string strUname = "select USERNAME from register where USERNAME ='" + txtusername.Text.Trim() + "'";
            //        cmd = new SqlCommand(strUname, con);

            //    }
            //}
        }
    }
}