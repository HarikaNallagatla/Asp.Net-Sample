﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Finalcasestudy
{
    public partial class WebForm10 : System.Web.UI.Page
    {
        static string connection = ConfigurationManager.ConnectionStrings["InsuranceConn"].ConnectionString;//@"Server=INCHCMPC011397;Database=Insurance;Trusted_Connection=true";
        static int userid = genRandomnum();
        static int password = genRandomnum();
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Text = "Welcome  " + Session["UserName"];
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection  con = new SqlConnection(connection))
            {
                string command = "Select * from Insurers where Agent_Id = '" + Session["AgentId"] + "'";
                using (SqlCommand cmd = new SqlCommand(command,con))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count>0)
                    {
                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                    }
                    else
                    {
                        MessageBox.Show("No Insurers");
                    }
                    
                }
            }
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            int nDOBYear = int.Parse(tbxdob.Text);
            int nCurrentYear = DateTime.Now.Year;
            tbxAge.Text = (nCurrentYear - nDOBYear).ToString();
        }

        protected void btncreate_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connection))
                {
                    con.Open();
                    string command = "Insert into Insurers values(@Ins_ID,@Password,@Name_of_Insurer,@Name_of_Nominee,@DOB,@Age,@Mode_Of_Payement,@Policy_Name,@Address,@Name_Of_Guardian,@InsuredAmount,@Agent_Id)";
                    using (SqlCommand cmd = new SqlCommand(command, con))
                    {
                        cmd.Parameters.AddWithValue("@Ins_ID", userid);
                        cmd.Parameters.AddWithValue("@Password", password);
                        cmd.Parameters.AddWithValue("@Name_of_Insurer", tbxinsurer.Text);
                        cmd.Parameters.AddWithValue("@Name_of_Nominee", tbxnominee.Text);
                        cmd.Parameters.AddWithValue("@DOB", tbxdob.Text);
                        cmd.Parameters.AddWithValue("@Age", tbxAge.Text);
                        cmd.Parameters.AddWithValue("@Mode_Of_Payement", DropDownList1.Text);
                        cmd.Parameters.AddWithValue("@Policy_Name", DropDownList2.Text);
                        cmd.Parameters.AddWithValue("@Address", tbxAddress.Text);
                        cmd.Parameters.AddWithValue("@Name_Of_Guardian", tbxguardian.Text);
                        cmd.Parameters.AddWithValue("@InsuredAmount", tbxsum.Text);
                        cmd.Parameters.AddWithValue("@Agent_Id", Session["AgentId"]);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Insurer had been created successfully");
                        MessageBox.Show("Insurer userid is" + userid.ToString() + "Password is"+password.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Sorry!! Account is not created successfully");
                MessageBox.Show(ex.Message);
            }
            
        }

       protected  static int genRandomnum()
        {
            int userid = 0;
            Random r = new Random();
            string w = "";
            int i;
            for (i = 1; i < 6; i++)
            {
                w += r.Next(0, 9).ToString();
            }
            if (w.Length == 5)
            {
                userid = Convert.ToInt32(w);

            }
            return userid;
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Session["UserName"] = " ";
            Session["AgentId"] = " ";
            Session["Password"] = " ";
            Response.Write("<script>alert('You have logged out successfully')</script>");
            Response.Redirect("~/FirstPagee.aspx",false);
        }
    }
}