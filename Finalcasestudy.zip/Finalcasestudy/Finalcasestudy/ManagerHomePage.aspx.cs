﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
namespace Finalcasestudy
{
    public partial class WebForm11 : System.Web.UI.Page
    {
        static string connection = ConfigurationManager.ConnectionStrings["InsuranceConn"].ConnectionString;//@"Server=INCHCMPC011397;Database=Insurance;Trusted_Connection=true";

        protected void Page_Load(object sender, EventArgs e)
        {
            lblusername.Text = "welcome  " + Session["UserName"];
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["UserName"] = " ";
            Session["ManagerId"] = " ";
            Session["Password"] = " ";
            Response.Write("<script>alert(You have logged out successfully)</script>");
            Response.Redirect("~/FirstPagee.aspx");
        }

        protected void btnAgentList_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AgentsListPage.aspx", false);
        }

        protected void btnPaymentmode_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/PaymentModePage.aspx", false);
        }
    }
}